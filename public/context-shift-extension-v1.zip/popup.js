
document.addEventListener('DOMContentLoaded', () => {
  let extractedChat = '';
  let migrationPrompt = '';
  
  const captureBtn = document.getElementById('captureBtn');
  const status = document.getElementById('status');
  const resultsDiv = document.getElementById('results');
  
  const promptOutput = document.getElementById('promptOutput');
  const copyPromptBtn = document.getElementById('copyPromptBtn');
  
  const chatOutput = document.getElementById('chatOutput');
  const copyChatBtn = document.getElementById('copyChatBtn');
  const downloadChatBtn = document.getElementById('downloadChatBtn');

  captureBtn.addEventListener('click', async () => {
    captureBtn.disabled = true;
    captureBtn.innerText = 'Capturing...';
    status.innerText = 'Scraping chat...';
    resultsDiv.style.display = 'none';
    
    try {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      
      if (!tab.url.includes('claude.ai')) {
        throw new Error('Please open a Claude.ai chat to use this extension.');
      }
      
      const results = await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        func: () => {
          // Find the main content area (avoids the sidebar which caused the "Sessions you start" bug)
          const mainArea = document.querySelector('main') || document.querySelector('.flex-1') || document.body;
          
          // Grab message divs. Claude typically uses .prose for its own messages.
          const elements = mainArea.querySelectorAll('.font-user-message, .font-claude-message, .prose, [data-is-user], [data-message-author]');
          
          let text = '';
          if (elements.length > 0) {
            let formattedChat = [];
            const uniqueTexts = new Set();
            
            elements.forEach(el => {
               let role = '--- CLAUDE RESPONSE ---';
               
               if (
                 el.getAttribute('data-is-user') === 'true' || 
                 el.getAttribute('data-message-author') === 'user' || 
                 el.classList.contains('font-user-message')
               ) {
                 role = '--- USER PROMPT ---';
               } else if (el.classList.contains('prose')) {
                 // If this .prose is inside a known wrapper we already selected, skip it to avoid duplication
                 if (el.parentElement && el.parentElement.closest('[data-is-user], [data-message-author], .font-user-message, .font-claude-message')) {
                   return;
                 }
               }

               const t = el.innerText.trim();
               // Filter out empty strings and sidebar noise
               if (t.length > 0 && t !== "Sessions you start will show up here" && !uniqueTexts.has(t)) {
                   uniqueTexts.add(t);
                   formattedChat.push(role + '\n\n' + t);
               }
            });
            text = formattedChat.join('\n\n=========================================\n\n');
          } else {
            // Fallback: grab all text in the main area
            text = mainArea.innerText;
          }
          
          return text.substring(0, 500000); // Limit to ~500k chars to prevent memory issues
        }
      });
      
      const chatText = results[0]?.result;
      
      if (!chatText || chatText.trim().length === 0) {
        throw new Error("Could not find any chat text on this page.");
      }
      
      migrationPrompt = `I am migrating an active development session from another AI to you.

I will provide the raw chat transcript in my next message (or attached as a text file).

Your first task is to deeply analyze the transcript and construct a comprehensive "Working Memory" for this project.

## INSTRUCTIONS FOR YOU:
1.  **Analyze**: Read through the provided transcript carefully. Ignore any UI noise.
2.  **Create Working Memory**: Create a structured summary of:
    *   **Project Goals:** What are we ultimately trying to build?
    *   **Current State:** Where exactly did we leave off?
    *   **Key Decisions:** What technical choices/frameworks are we using?
    *   **Pending Tasks:** What is the immediate next step or unresolved issue?
3.  **Acknowledge**: Respond ONLY with this "Working Memory" summary. Do NOT start writing code for the next step yet. Wait for my confirmation.`;
      
      extractedChat = chatText;
      
      promptOutput.value = migrationPrompt;
      chatOutput.value = extractedChat;
      
      resultsDiv.style.display = 'block';
      status.innerText = 'Success! Context extracted.';
      captureBtn.innerText = 'Extract Again';
      captureBtn.disabled = false;
      
    } catch (error) {
      status.innerText = 'Error: ' + error.message;
      captureBtn.innerText = 'Extract Chat Context';
      captureBtn.disabled = false;
    }
  });

  copyPromptBtn.addEventListener('click', () => {
    navigator.clipboard.writeText(migrationPrompt).then(() => {
      const originalText = copyPromptBtn.innerText;
      copyPromptBtn.innerText = 'Copied!';
      setTimeout(() => { copyPromptBtn.innerText = originalText; }, 2000);
    });
  });

  copyChatBtn.addEventListener('click', () => {
    navigator.clipboard.writeText(extractedChat).then(() => {
      const originalText = copyChatBtn.innerText;
      copyChatBtn.innerText = 'Copied!';
      setTimeout(() => { copyChatBtn.innerText = originalText; }, 2000);
    }).catch(err => {
      status.innerText = 'Copy failed: ' + err.message;
    });
  });

  downloadChatBtn.addEventListener('click', () => {
    const blob = new Blob([extractedChat], { type: 'text/plain' });
    const reader = new FileReader();
    reader.onload = function() {
      chrome.downloads.download({
        url: reader.result,
        filename: 'claude-chat-transcript.txt',
        saveAs: true
      });
    };
    reader.readAsDataURL(blob);
  });
});

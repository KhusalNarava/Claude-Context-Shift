
document.addEventListener('DOMContentLoaded', () => {
  let generatedMarkdown = '';
  const captureBtn = document.getElementById('captureBtn');
  const status = document.getElementById('status');
  const resultsDiv = document.getElementById('results');
  const markdownOutput = document.getElementById('markdownOutput');
  const copyBtn = document.getElementById('copyBtn');
  const downloadBtn = document.getElementById('downloadBtn');

  captureBtn.addEventListener('click', async () => {
    captureBtn.disabled = true;
    captureBtn.innerText = 'Capturing...';
    status.innerText = 'Scraping chat...';
    resultsDiv.style.display = 'none';
    
    try {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      
      if (!tab.url.includes('claude.ai')) {
        throw new Error('Please open a Claude.ai chat to use this extension.');
      }
      
      const results = await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        func: () => {
          // Find the main content area (avoids the sidebar which caused the "Sessions you start" bug)
          const mainArea = document.querySelector('main') || document.querySelector('.flex-1') || document.body;
          
          // Grab message divs. Claude typically uses .prose for its own messages.
          const elements = mainArea.querySelectorAll('.font-user-message, .font-claude-message, .prose, [data-is-user], [data-message-author]');
          
          let text = '';
          if (elements.length > 0) {
            const uniqueTexts = new Set();
            elements.forEach(el => {
               const t = el.innerText.trim();
               // Filter out empty strings and sidebar noise
               if (t.length > 0 && t !== "Sessions you start will show up here" && !uniqueTexts.has(t)) {
                   uniqueTexts.add(t);
               }
            });
            text = Array.from(uniqueTexts).join('\n\n--- [Message Boundary] ---\n\n');
          } else {
            // Fallback: grab all text in the main area
            text = mainArea.innerText;
          }
          
          return text.substring(0, 500000); // Limit to ~500k chars to prevent memory issues
        }
      });
      
      const chatText = results[0]?.result;
      
      if (!chatText || chatText.trim().length === 0) {
        throw new Error("Could not find any chat text on this page.");
      }
      
      const fixedPrompt = `# CONTEXT MIGRATION & CONTINUATION INSTRUCTIONS

You are an expert AI developer assistant. We are migrating an active development session from another AI to you.

Your first task is to deeply analyze the provided chat transcript below and construct a comprehensive "Working Memory" for this project.

## INSTRUCTIONS FOR YOU:
1.  **Analyze**: Read through the entire transcript below carefully. Ignore any noise or duplicated UI text from the scraping process.
2.  **Create Working Memory**: Based on the chat, create a structured summary of:
    *   **Project Goals:** What are we ultimately trying to build?
    *   **Current State:** Where exactly did we leave off?
    *   **Key Decisions & Architecture:** What technical choices have been made? What tools/frameworks are we using?
    *   **Pending Tasks:** What was the immediate next step or unresolved issue when the chat ended?
3.  **Acknowledge & Prepare**: Respond with your "Working Memory" summary to confirm you understand the context. Do NOT start writing code for the next step yet. Wait for my confirmation and my next specific instruction after you provide the summary.

---

# RAW SCRAPED CHAT TRANSCRIPT:

${chatText}`;
      
      generatedMarkdown = fixedPrompt;
      markdownOutput.value = generatedMarkdown;
      resultsDiv.style.display = 'block';
      
      status.innerText = 'Success! Context extracted.';
      captureBtn.innerText = 'Extract Again';
      captureBtn.disabled = false;
      
    } catch (error) {
      status.innerText = 'Error: ' + error.message;
      captureBtn.innerText = 'Extract Chat Context';
      captureBtn.disabled = false;
    }
  });

  copyBtn.addEventListener('click', () => {
    navigator.clipboard.writeText(generatedMarkdown).then(() => {
      const originalText = copyBtn.innerText;
      copyBtn.innerText = 'Copied!';
      setTimeout(() => { copyBtn.innerText = originalText; }, 2000);
    }).catch(err => {
      status.innerText = 'Copy failed: ' + err.message;
    });
  });

  downloadBtn.addEventListener('click', () => {
    const blob = new Blob([generatedMarkdown], { type: 'text/markdown' });
    const reader = new FileReader();
    reader.onload = function() {
      chrome.downloads.download({
        url: reader.result,
        filename: 'claude-chat-context.md',
        saveAs: true
      });
    };
    reader.readAsDataURL(blob);
  });
});
